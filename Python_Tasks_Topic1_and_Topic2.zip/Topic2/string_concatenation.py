first_name = "John"
last_name = "Doe"
full_name = first_name + " " + last_name

print("Full Name:", full_name)