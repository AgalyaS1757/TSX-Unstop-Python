# Arithmetic
print(5 + 2, 5 - 2, 5 * 2, 5 / 2, 5 // 2, 5 % 2, 5 ** 2)

# Logical
print(True and False)
print(True or False)
print(not False)