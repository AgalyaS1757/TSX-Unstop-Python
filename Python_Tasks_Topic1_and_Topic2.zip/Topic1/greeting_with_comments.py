# This script prints a greeting with the user's name

# Store the name in a variable
name = "John"

# Print a greeting message
print("Hello, " + name + "! Welcome to Python.")